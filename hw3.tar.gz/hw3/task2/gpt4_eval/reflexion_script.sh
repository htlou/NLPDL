python reflexion.py \
    --input-file /data/align-anything/hantao/data/gsm8k/test.json \
    --output-dir ./outputs \
    --max-iterations 3 \
    --openai-api-key-file config/openai_api_keys.txt \
    --num-workers 50